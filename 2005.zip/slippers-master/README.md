# Slippers
![In-game preview](https://i.imgur.com/FqjM7Gf.png)
### Getting Started
For help on setting up a Slippers server see the [wiki](https://github.com/wizguin/slippers/wiki).
### Disclaimer
Slippers is not yet ready and should not be used for a public Club Penguin private server.
